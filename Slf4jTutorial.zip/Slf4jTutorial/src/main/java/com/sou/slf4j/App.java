package com.sou.slf4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class App {

	private static final Logger slf4jLogger = LoggerFactory.getLogger(App.class);
	
	public static void main(String[] args) {
		String name = "Soubhab";
        slf4jLogger.debug("Hi, {}", name);
        slf4jLogger.info("Welcome to the HelloWorld example of Logback.");
        slf4jLogger.warn("Dummy warning message.");
        slf4jLogger.error("Dummy error message.");
	}

}